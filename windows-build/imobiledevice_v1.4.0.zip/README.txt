libimobiledevice Windows 编译产物
================================

编译时间: Thu Dec 11 17:38:19 CST 2025
编译环境: MINGW64
编译器: gcc.exe (Rev8, Built by MSYS2 project) 15.2.0

目录结构:
---------
bin/         - 可执行文件和 DLL 文件
lib/         - 静态库和导入库
include/     - 头文件
pkgconfig/   - pkg-config 文件

使用说明:
---------
1. 将 bin/ 目录添加到系统 PATH 环境变量
2. 或者直接从 bin/ 目录运行工具

可用工具:
---------
afcclient.exe
idevice_id.exe
idevicebackup.exe
idevicebackup2.exe
idevicebtlogger.exe
idevicecrashreport.exe
idevicedate.exe
idevicedebug.exe
idevicedebugserverproxy.exe
idevicedevmodectl.exe
idevicediagnostics.exe
ideviceenterrecovery.exe
ideviceimagemounter.exe
ideviceinfo.exe
idevicename.exe
idevicenotificationproxy.exe
idevicepair.exe
ideviceprovision.exe
idevicescreenshot.exe
idevicesetlocation.exe
idevicesyslog.exe

依赖的 DLL:
-----------
libcrypto-3-x64.dll
libcurl-4.dll
libgcc_s_seh-1.dll
libiconv-2.dll
libimobiledevice-glue-1.0.dll
libplist++-2.0.dll
libplist-2.0.dll
libssl-3-x64.dll
libstdc++-6.dll
libtatsu.dll
libusbmuxd-2.0.dll
libwinpthread-1.dll
zlib1.dll

